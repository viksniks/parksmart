export const environment = {
  production: true,
  baseURL: {
    url: 'http://localhost:3000/api'
  }
};
