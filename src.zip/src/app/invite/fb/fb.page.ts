import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fb',
  templateUrl: './fb.page.html',
  styleUrls: ['./fb.page.scss'],
})
export class FbPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
