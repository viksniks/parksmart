export class UserModel {
    _id: String;
    fullName: String;
    email: String;
    mobileNumber: Number;
    password: String;
}
