export interface Museum{
    name: string;
    state : string;
    latitude: any;
    longitude:any
}