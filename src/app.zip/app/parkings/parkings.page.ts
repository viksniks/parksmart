import { Component, OnInit } from '@angular/core';
declare var google;
@Component({
  selector: 'app-parkings',
  templateUrl: './parkings.page.html',
  styleUrls: ['./parkings.page.scss'],
})
export class ParkingsPage implements OnInit {
map:any;
bounds:any = new google.maps.LatLngBounds();
  constructor() { }

  ngOnInit() {
    this.initMap();
  }
  initMap() {
    // The location of Uluru
    const uluru = { lat: -25.344, lng: 131.036 };
    // The map, centered at Uluru
    this.map = new google.maps.Map(document.getElementById("map"), {
      zoom: 4,
      center: uluru,
    });
   this.getNearestParkings();
    // The marker, positioned at Uluru
    
  }
  getNearestParkings()
  {
   let arr = [{latitude:28.590877777777777,longitude:77.6195},
   {latitude:28.38034,longitude:76.88609833333334},
   {latitude:28.375896666666666,longitude:76.90506333333333}];
 for(var i = 0;i<arr.length;i++)
 {
   let latlng = new google.maps.LatLng(arr[i].latitude, arr[i].longitude);
   
  const marker = new google.maps.Marker({
    position: latlng,
    map: this.map,
  });
   this.bounds.extend(latlng);
 }
   
   
   this.map.fitBounds(this.bounds);
  }
  

}
